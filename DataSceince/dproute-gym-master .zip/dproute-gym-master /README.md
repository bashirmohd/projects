# dproute-gym
AI gym for DEEP-ROUTE

This is a simulation of DEEP-ROUTE link selection experiment. 
DEEP-ROUTE has two links - one  dedicated (EXOGENI)MPLS circuit from CHI@UC to CHI@TACC and other over internet2 which is a low cost option. 
The experiment is to demostrate and represent the dynamic link selection as a reinforcement learning experiment.
